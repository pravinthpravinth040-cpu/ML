"""
TrustCred AI - synthetic dataset generator.
Run:  python ml-training/generate_datasets.py
All data is SYNTHETIC (seeded, reproducible). Nothing here is real vendor or lender data.
"""
import csv, json, hashlib, random, base64
from datetime import datetime, timedelta
from pathlib import Path
import numpy as np
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

SEED = 2026
random.seed(SEED); np.random.seed(SEED)
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "ml-training" / "data"
SEEDDB = ROOT / "backend" / "database" / "seed"
NOW = datetime(2026, 10, 10, 12, 0, 0)          # snapshot time for statuses
N_VENDORS = 50
MONTHS = ["2026-06", "2026-07", "2026-08", "2026-09"]
KEY_ID = "demo-key-01"
MODEL_VERSION = "scorecard-v0.1;txn-classifier-v0.1"


def ts(d): return d.strftime("%Y-%m-%d %H:%M:%S")


def write_csv(path, rows, cols):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader()
        for r in rows:
            w.writerow({c: ("" if r.get(c) is None else r.get(c)) for c in cols})
    print(f"{path.relative_to(ROOT)}: {len(rows)} rows")


def pick(seq, weights=None): return random.choices(seq, weights=weights)[0]


# ------------------------------------------------------------------ reference data
TYPES = {
    "tea_stall":         dict(rec=(35000, 70000),  ratio=(.55, .70), ticket=(15, 120),   vol=.15, goods=["tea", "coffee", "vadai", "bun", "snacks"], items=["milk", "tea powder", "sugar", "gas cylinder", "snacks stock"]),
    "vegetable_cart":    dict(rec=(30000, 65000),  ratio=(.65, .80), ticket=(60, 600),   vol=.25, goods=["vegetables", "onion", "tomato", "greens", "fruits"], items=["wholesale vegetables", "market stock", "cart rent", "packing covers"]),
    "flower_seller":     dict(rec=(25000, 55000),  ratio=(.50, .65), ticket=(30, 400),   vol=.35, goods=["jasmine", "garland", "flowers", "rose", "pooja flowers"], items=["flower wholesale", "thread", "banana leaf", "market stock"]),
    "tiffin_stall":      dict(rec=(45000, 90000),  ratio=(.55, .70), ticket=(30, 250),   vol=.18, goods=["idli", "dosa", "tiffin", "meals", "parcel"], items=["rice", "urad dal", "oil", "gas cylinder", "coconut"]),
    "juice_shop":        dict(rec=(40000, 80000),  ratio=(.50, .65), ticket=(30, 200),   vol=.28, goods=["juice", "milkshake", "sugarcane", "fruit bowl", "lassi"], items=["fruit wholesale", "ice", "milk", "cups", "gas cylinder"]),
    "tailoring":         dict(rec=(25000, 50000),  ratio=(.30, .45), ticket=(100, 1500), vol=.30, goods=["stitching", "blouse", "alteration", "uniform", "stitching advance"], items=["cloth stock", "thread", "buttons", "machine service"]),
    "street_snacks":     dict(rec=(35000, 75000),  ratio=(.55, .70), ticket=(20, 180),   vol=.22, goods=["pani puri", "bhel", "bajji", "sundal", "corn"], items=["flour", "oil", "gas cylinder", "potato", "packing"]),
    "fish_vendor":       dict(rec=(45000, 95000),  ratio=(.70, .82), ticket=(150, 1800), vol=.30, goods=["fish", "prawn", "crab", "fish order", "dry fish"], items=["fish auction", "ice", "transport", "crate rent"]),
    "kirana_store":      dict(rec=(80000, 180000), ratio=(.78, .88), ticket=(60, 1500),  vol=.12, goods=["groceries", "provisions", "rice bag", "oil", "bill"], items=["wholesale stock", "distributor payment", "packing", "transport"]),
    "mobile_accessories": dict(rec=(50000, 110000), ratio=(.70, .82), ticket=(80, 3000), vol=.25, goods=["charger", "cover", "earphones", "recharge", "tempered glass"], items=["wholesale accessories", "distributor", "courier", "shop rent"]),
}
LOCATIONS = ["Madurai", "Chennai", "Coimbatore", "Tiruchirappalli", "Salem", "Tirunelveli", "Erode", "Thanjavur", "Vellore", "Tiruppur"]
FIRST = ["Murugan", "Selvi", "Karthik", "Lakshmi", "Ramesh", "Kavitha", "Suresh", "Meena", "Arun", "Priya", "Saravanan", "Divya", "Manikandan", "Revathi", "Vignesh", "Anitha", "Pandi", "Valli", "Senthil", "Bharathi", "Ganesh", "Deepa", "Rajesh", "Malathi", "Kumar", "Sangeetha", "Balaji", "Thenmozhi", "Dinesh", "Jothi"]
INIT = list("ABCDGKMNPRSTV")
BANKS = ["okaxis", "oksbi", "okhdfcbank", "ybl", "paytm", "ibl", "axl", "upi"]
PLACES = ["Madurai", "Meenakshi", "Anna Nagar", "Periyar", "Mahal", "Pandian", "Vasantham", "Selvam", "Kamarajar", "Arasan"]


def person(): return f"{pick(FIRST).upper()} {pick(INIT)}"
def ref(): return str(random.randint(10 ** 11, 10 ** 12 - 1))
def supplier(): return pick([f"SRI {pick(PLACES).upper()} TRADERS", f"{pick(PLACES).upper()} WHOLESALE", f"{pick(PLACES).upper()} AGENCIES", f"{pick(FIRST).upper()} STORES"])


# ------------------------------------------------------------------ keys (demo only)
priv = Ed25519PrivateKey.generate()
pub_pem = priv.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
priv_pem = priv.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
SEEDDB.mkdir(parents=True, exist_ok=True)
(SEEDDB / f"{KEY_ID}_public.pem").write_bytes(pub_pem)
(SEEDDB / f"DEMO_ONLY_{KEY_ID}_private.pem").write_bytes(priv_pem)

# ------------------------------------------------------------------ lenders
LENDERS = [("L001", "Meenakshi Micro Finance", "microfinance_institution", "Madurai"),
           ("L002", "Kaveri Cooperative Bank", "cooperative_bank", "Tiruchirappalli"),
           ("L003", "Pandian Small Business Finance", "nbfc", "Chennai"),
           ("L004", "Coimbatore Vendors Credit Society", "credit_society", "Coimbatore"),
           ("L005", "Tamirabarani Rural Bank", "regional_rural_bank", "Tirunelveli")]
lenders = [dict(lender_id=a, lender_name=b, lender_type=c, city=d, signing_key_id_trusted=KEY_ID) for a, b, c, d in LENDERS]

# ------------------------------------------------------------------ vendor_profiles (Dataset 5)
profiles = []
for i in range(1, N_VENDORS + 1):
    vt = list(TYPES)[(i - 1) % len(TYPES)] if i <= 40 else pick(list(TYPES))
    reg = pick(["udyam_registered", "local_vending_certificate", "none", "pending"], [.20, .25, .40, .15])
    ev = {"business_photo"}
    if reg == "udyam_registered": ev.add("udyam_certificate")
    if reg == "local_vending_certificate": ev.add("vending_certificate")
    for d in ["supplier_bill", "bank_statement", "utility_bill"]:
        if random.random() < .55: ev.add(d)
    if len(ev) < 2: ev.add("supplier_bill")
    age = int(np.clip(np.random.lognormal(3.4, .8), 4, 120))
    profiles.append(dict(vendor_id=f"V{i:03d}", vendor_name=f"{pick(INIT)}. {pick(FIRST)}", business_type=vt,
                         business_age_months=age, operating_location=pick(LOCATIONS), registration_status=reg,
                         available_alternative_evidence=";".join(sorted(ev)),
                         onboarded_date=(datetime(2026, 5, 1) + timedelta(days=random.randint(0, 120))).strftime("%Y-%m-%d")))
PROF = {p["vendor_id"]: p for p in profiles}

# ------------------------------------------------------------------ vendor_monthly_financials (Dataset 3)
financials = []
VF = {}
for p in profiles:
    t = TYPES[p["business_type"]]
    r0 = random.uniform(*t["rec"]); g = random.gauss(.01, .03)
    ratio = random.uniform(*t["ratio"]); vol = t["vol"] * random.uniform(.7, 1.4)
    debt = 0 if random.random() < .50 else random.choice(range(1000, 12001, 100))
    comp0 = random.uniform(.45, 1.0)
    for k, m in enumerate(MONTHS):
        base = r0 * (1 + g) ** k * random.uniform(.92, 1.08)
        weeks = [max(base / 4 * (1 + random.gauss(0, vol)), base / 4 * .2) for _ in range(4)]
        rec = sum(weeks); cv = float(np.std(weeks) / np.mean(weeks))
        exp = rec * ratio * (1 + random.gauss(0, .04))
        comp = float(np.clip(comp0 + random.uniform(-.08, .08), .30, 1.0))
        src = "verified_transactions" if comp >= .75 else "estimated_from_partial_data"
        if src.startswith("estimated"):
            rec *= 1 + random.gauss(0, .08); exp *= 1 + random.gauss(0, .08)
        rec, exp = round(rec), round(exp)
        row = dict(vendor_id=p["vendor_id"], period_month=m, business_type=p["business_type"],
                   business_age_months=p["business_age_months"], business_receipts=rec, business_expenses=exp,
                   net_cashflow=rec - exp, cashflow_variability=round(cv, 3),
                   existing_monthly_debt_payments=debt, data_completeness=round(comp, 2), value_source=src)
        financials.append(row); VF.setdefault(p["vendor_id"], []).append(row)


# ------------------------------------------------------------------ transactions + labels (Datasets 1, 2)
def mk_txn(cat, vt):
    t = TYPES[vt]; meta = False
    lo, hi = t["ticket"]
    if cat == "business_receipt":
        d = "credit"; amt = int(np.clip(round(np.random.lognormal(np.log((lo * hi) ** .5), .55)), lo, hi * 2))
        r = random.random()
        if r < .50: desc = f"UPI/CR/{ref()}/{person()}/{pick(BANKS)}/{pick(t['goods'])}"
        elif r < .68: desc = f"UPI/CR/{ref()}/{person()}/{pick(BANKS)}/Payment from PhonePe"
        elif r < .78: desc = f"UPI/CR/{ref()}/{person()}/{pick(BANKS)}/UPI"
        elif r < .90: desc = f"QR SETTLEMENT/{random.randint(10 ** 7, 10 ** 8 - 1)}/GPay Merchant"; meta = True
        else: desc = pick([f"PAYTM SOUNDBOX CREDIT {ref()}", f"BHARATPE SETTLEMENT {ref()[:8]}"]); meta = True
    elif cat == "business_expense":
        d = "debit"; amt = int(round(random.uniform(300, 15000), -1))
        r = random.random()
        if r < .6: desc = f"UPI/DR/{ref()}/{supplier()}/{pick(BANKS)}/{pick(t['items'])}"
        elif r < .8: desc = f"UPI/DR/{ref()}/{supplier()}/{pick(BANKS)}/stock payment"
        elif r < .9: desc = f"POS/GAS AGENCY/{ref()}"
        else: desc = f"UPI/DR/{ref()}/{pick(PLACES).upper()} MARKET/stall rent"
    elif cat == "personal_transfer":
        if random.random() < .65:
            d = "debit"; amt = int(round(random.uniform(300, 10000), -2))
            desc = f"UPI/DR/{ref()}/{person()}/{pick(BANKS)}/{pick(['home', 'amma', 'rent', 'school fees', 'mobile recharge', 'groceries home', 'family', 'medical'])}"
            if random.random() < .12: desc = f"UPI/DR/{ref()}/{person()}/{pick(BANKS)}/payment"
        else:
            d = "credit"; amt = int(round(random.uniform(500, 12000), -2))
            desc = f"UPI/CR/{ref()}/{person()}/{pick(BANKS)}/{pick(['sent by brother', 'anna', 'family help', 'chitti', 'gift', 'amma'])}"
            if random.random() < .12: desc = f"UPI/CR/{ref()}/{person()}/{pick(BANKS)}/ok"
    elif cat == "refund":
        if random.random() < .5:
            d = "credit"; amt = int(random.uniform(100, 3000))
            desc = pick([f"REFUND/{ref()}/supplier refund wrong item", f"UPI/CR/{ref()}/{supplier()}/{pick(BANKS)}/refund", f"REVERSAL/{ref()}/failed payment"])
        else:
            d = "debit"; amt = int(random.uniform(30, 1500))
            desc = f"UPI/DR/{ref()}/{person()}/{pick(BANKS)}/refund customer"
    else:  # unknown
        d = pick(["credit", "debit"]); amt = int(random.uniform(10, 5000))
        dd = "CR" if d == "credit" else "DR"
        desc = pick([f"UPI/{dd}/{ref()}/{person()}/{pick(BANKS)}/", f"UPI/{dd}/{ref()}/NA/NA/NA", f"NEFT-{ref()}", f"TRANSFER {ref()[:8]}",
                     f"UPI/{dd}/{ref()}/{person()}/{pick(BANKS)}/thanks", f"UPI/{dd}/{ref()}/{person()}/{pick(BANKS)}/paid"])
    hour = random.randint(4, 11) if cat == "business_expense" else int(np.clip(random.gauss(13, 4.5), 6, 22))
    return dict(cat=cat, direction=d, amount=amt, description=desc, meta=meta, hour=hour)


plan = {"business_receipt": 100, "business_expense": 54, "refund": 14, "personal_transfer": 36, "unknown": 22}
raw = []
for cat, n in plan.items():
    for _ in range(n):
        vid = pick([p["vendor_id"] for p in profiles])
        x = mk_txn(cat, PROF[vid]["business_type"]); x["vendor_id"] = vid
        day = datetime(2026, 6, 1) + timedelta(days=random.randint(0, 121))
        x["date"] = day.replace(hour=x["hour"], minute=random.randint(0, 59), second=random.randint(0, 59))
        raw.append(x)
originals = [x for x in raw if x["cat"] in ("business_receipt", "business_expense")]
for _ in range(14):
    o = random.choice(originals); c = dict(o)
    c["cat"] = "duplicate"; c["meta"] = True; c["date"] = o["date"] + timedelta(seconds=random.randint(5, 120))
    raw.append(c)
raw.sort(key=lambda x: x["date"])
unverified_idx = set(random.sample(range(len(raw)), 40))
txns, labels = [], []
for i, x in enumerate(raw, 1):
    tid = f"TXN{i:05d}"
    row = dict(transaction_id=tid, vendor_id=x["vendor_id"], date=ts(x["date"]), amount=x["amount"],
               direction=x["direction"], description=x["description"], category="", verification_status="")
    if (i - 1) in unverified_idx:
        row["verification_status"] = pick(["unverified", "pending_review"], [.7, .3])
    else:
        if x["meta"]: status, src = "source_verified", "reliable_metadata"
        elif x["cat"] == "unknown": status, src = pick([("human_reviewed", "human_review"), ("vendor_confirmed", "vendor_confirmed")], [.8, .2])
        else: status, src = pick([("vendor_confirmed", "vendor_confirmed"), ("human_reviewed", "human_review")], [.6, .4])
        row["category"] = x["cat"]; row["verification_status"] = status
        labels.append(dict(transaction_id=tid, description=x["description"], amount=x["amount"], direction=x["direction"],
                           verified_category=x["cat"], label_source=src))
    txns.append(row)


# ------------------------------------------------------------------ applications + consent + assessment + reports
def purpose_for(vt):
    return pick(["stock purchase", "working capital", "new cart or stall equipment", "refrigerator or equipment", "shop expansion", "repairs and maintenance", "digital payment setup"])


def canonical(d): return json.dumps(d, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def assess(vid, amount, months):
    rows = VF[vid]; p = PROF[vid]
    avg_net = np.mean([r["net_cashflow"] for r in rows])
    avg_cv = np.mean([r["cashflow_variability"] for r in rows]); avg_comp = np.mean([r["data_completeness"] for r in rows])
    exp_ratio = sum(r["business_expenses"] for r in rows) / sum(r["business_receipts"] for r in rows)
    debt = rows[-1]["existing_monthly_debt_payments"]
    emi = amount * (1 + 0.20 * months / 12) / months      # illustrative flat 20% p.a.
    cover = (avg_net - debt) / emi
    pts = dict(
        income_stability=25 * (1 - min(avg_cv, .8) / .8),
        repayment_capacity=30 * min(max(cover, 0) / 3, 1),
        business_continuity=15 * min(p["business_age_months"] / 36, 1),
        expense_discipline=15 * (1 - min(max((exp_ratio - .4) / .5, 0), 1)),
        evidence_coverage=15 * avg_comp)
    mx = dict(income_stability=25, repayment_capacity=30, business_continuity=15, expense_discipline=15, evidence_coverage=15)
    txt = dict(
        income_stability=f"Weekly receipts varied by {avg_cv * 100:.0f}% on average across the 4 months (lower means steadier income).",
        repayment_capacity=f"Average monthly net cash flow INR {avg_net:,.0f} less existing obligations INR {debt:,.0f} covers the proposed instalment of INR {emi:,.0f} about {cover:.1f}x (full marks at 3x).",
        business_continuity=f"Business has operated for {p['business_age_months']} months (full marks at 36 months).",
        expense_discipline=f"Business expenses were {exp_ratio * 100:.0f}% of receipts (full marks at or below 40%, zero at 90%).",
        evidence_coverage=f"Payment evidence covered {avg_comp * 100:.0f}% of the expected activity on average.")
    val = dict(income_stability=round(float(avg_cv), 3), repayment_capacity=round(float(cover), 2), business_continuity=p["business_age_months"],
               expense_discipline=round(float(exp_ratio), 3), evidence_coverage=round(float(avg_comp), 2))
    factors = []
    for k in pts:
        s = round(float(pts[k]), 1); frac = s / mx[k]
        factors.append(dict(factor=k, value=val[k], points=s, max_points=mx[k],
                            impact="strong" if frac >= .75 else "adequate" if frac >= .4 else "weak", explanation=txt[k]))
    score = round(sum(f["points"] for f in factors))
    band = "strong_evidence" if score >= 75 else "moderate_evidence" if score >= 55 else "limited_evidence" if score >= 35 else "insufficient_evidence"
    conf = "high" if avg_comp >= .85 else "medium" if avg_comp >= .65 else "low"
    est = sum(r["value_source"].startswith("estimated") for r in rows)
    lim = ["Based on 4 months of payment history (2026-06 to 2026-09); seasonal patterns outside this window are not captured.",
           "Reflects cash-flow evidence only. It is not a credit score and does not predict repayment behaviour (no repayment history was used).",
           "Proposed instalment is illustrative: flat 20% annual rate assumed; the lender's actual terms may differ."]
    if est: lim.append(f"Receipts and expenses were estimated from partial data in {est} of 4 months.")
    if p["business_age_months"] < 12: lim.append("Business is under 12 months old; limited operating history.")
    if p["registration_status"] in ("none", "pending"): lim.append("No confirmed business registration; assessed on payment evidence and alternative documents only.")
    if debt: lim.append("Existing monthly obligations are vendor-declared and not independently verified.")
    return score, band, conf, factors, lim


apps = []
for i in range(200):
    vid = f"V{(i % N_VENDORS) + 1:03d}"
    p = PROF[vid]; avg_rec = np.mean([r["business_receipts"] for r in VF[vid]])
    amount = int(np.clip(round(avg_rec * random.uniform(.5, 5.0) / 5000) * 5000, 10000, 150000))
    months = pick([6, 9, 12, 18, 24])
    granted = datetime(2026, 10, 1) + timedelta(seconds=random.randint(0, 9 * 86400 - 3600))
    submitted = granted + timedelta(minutes=random.randint(1, 3))
    lender = pick([l["lender_id"] for l in lenders])
    apps.append(dict(vid=vid, amount=amount, months=months, granted=granted, submitted=submitted, lender=lender, p=p))
apps.sort(key=lambda a: a["granted"])

consents, reports = [], []
for i, a in enumerate(apps, 1):
    aid, cid, rid = f"APP{i:04d}", f"CON{i:04d}", f"RPT{i:04d}"
    score, band, conf, factors, lim = assess(a["vid"], a["amount"], a["months"])
    created = a["submitted"] + timedelta(minutes=random.randint(1, 10))
    days = pick([3, 7, 14, 30], [.15, .25, .30, .30]); expiry = a["granted"] + timedelta(days=days)
    revoked = None
    if random.random() < .16:
        lo = created + timedelta(hours=1); hi = min(expiry, NOW) - timedelta(minutes=5)
        if hi > lo: revoked = lo + timedelta(seconds=random.randint(0, int((hi - lo).total_seconds())))
    status = "revoked" if revoked else "expired" if expiry < NOW else "active"
    scope = ["assessment_report", "factor_explanations"]
    if random.random() < .70: scope.append("monthly_summary")
    if random.random() < .45: scope.append("category_summary")
    if random.random() < .25: scope.append("evidence_document_review")
    consents.append(dict(consent_id=cid, application_id=aid, vendor_id=a["vid"], lender_id=a["lender"], allowed_data_scope=";".join(scope),
                         purpose=pick(["loan_application_assessment", "credit_limit_review"], [.85, .15]), granted_time=ts(a["granted"]),
                         expiry_time=ts(expiry), revoked_time=ts(revoked) if revoked else "", consent_status=status))
    if revoked:
        st = "pending"
    else:
        w = {"strong_evidence": [.45, .2, .2, .1, .05], "moderate_evidence": [.2, .25, .25, .2, .1],
             "limited_evidence": [.05, .2, .2, .3, .25], "insufficient_evidence": [0, .1, .15, .25, .5]}[band]
        st = pick(["approved", "under_review", "pending", "more_documents_requested", "rejected"], w)
    a["row"] = dict(application_id=aid, vendor_id=a["vid"], requested_amount=a["amount"], loan_purpose=purpose_for(a["p"]["business_type"]),
                    preferred_repayment_months=a["months"], application_status=st, lender_id=a["lender"], submitted_time=ts(a["submitted"]))
    a.update(aid=aid, cid=cid, rid=rid, created=created, expiry=expiry, revoked=revoked, cstatus=status, score=score, band=band, st=st, scope=scope)
    payload = dict(report_id=rid, application_id=aid, vendor_id=a["vid"], lender_id=a["lender"], consent_id=cid, score=score, score_band=band,
                   confidence=conf, factors=factors, limitations=lim, model_version=MODEL_VERSION, created_at=ts(created))
    h = hashlib.sha256(canonical(payload).encode("utf-8")).hexdigest()
    sig = base64.b64encode(priv.sign(h.encode("utf-8"))).decode()
    a["hash"] = h
    reports.append(dict(report_id=rid, application_id=aid, vendor_id=a["vid"], lender_id=a["lender"], consent_id=cid, assessment_score=score,
                        score_band=band, confidence=conf, factor_explanations=json.dumps(factors, ensure_ascii=False),
                        limitations=json.dumps(lim, ensure_ascii=False), model_version=MODEL_VERSION, report_hash=h,
                        signature_reference=f"{KEY_ID}:{sig}", created_time=ts(created),
                        report_status={"active": "active", "expired": "expired", "revoked": "withdrawn"}[status]))
applications = [a["row"] for a in apps]

# ------------------------------------------------------------------ evidence_documents (Dataset 8)
docs = []
for p in profiles:
    types = p["available_alternative_evidence"].split(";")
    for k in range(4):
        if k < len(types): dt_ = types[k]
        else: dt_ = random.choice(["supplier_bill", "bank_statement"] if "supplier_bill" in types else types)
        up = datetime(2026, 9, 25) + timedelta(seconds=random.randint(0, 14 * 86400))
        vs = pick(["verified", "pending_review", "needs_resubmission", "rejected"], [.60, .20, .10, .10])
        rv = "" if vs == "pending_review" else ts(min(up + timedelta(hours=random.randint(2, 72)), NOW))
        docs.append(dict(vendor_id=p["vendor_id"], document_type=dt_, uploaded_time=ts(up), verification_status=vs, review_timestamp=rv))
docs.sort(key=lambda d: d["uploaded_time"])
for i, d in enumerate(docs, 1):
    d["document_id"] = f"DOC{i:04d}"
    d["secure_storage_reference"] = f"vault://trustcred-docs/{d['vendor_id']}/DOC{i:04d}.enc"
    d["content_hash"] = hashlib.sha256(f"synthetic-doc-{i}".encode()).hexdigest()
    d["lender_access"] = "restricted_consent_required"

# ------------------------------------------------------------------ loan_repayment_history (Dataset 4) - SYNTHETIC, not for performance claims
loans = []
rel = {p["vendor_id"]: random.uniform(.55, .98) for p in profiles}
for i in range(1, 201):
    vid = pick([p["vendor_id"] for p in profiles]); amt = random.choice(range(5000, 60001, 5000)); n = random.choice([6, 9, 12])
    mo = round(amt * 1.15 / n, -1)
    due = datetime(2026, 1, 5) + timedelta(days=random.randint(0, 250))
    if random.random() < rel[vid]: dpd = max(0, random.randint(-2, 4))
    else: dpd = random.choice([7, 15, 20, 30, 45, 60, 75, 95, 110, 120])
    actual = due + timedelta(days=dpd + (0 if dpd else random.randint(-2, 0)))
    unpaid = dpd >= 60 and random.random() < .35
    if unpaid or actual > NOW:
        actual_s = ""; dpd = max(0, (NOW - due).days)
    else:
        actual_s = actual.strftime("%Y-%m-%d")
    loans.append(dict(loan_id=f"LN{i:04d}", vendor_id=vid, loan_amount=amt, monthly_obligation=int(mo), repayment_due_date=due.strftime("%Y-%m-%d"),
                      actual_payment_date=actual_s, days_past_due=dpd, default_status=1 if dpd >= 90 else 0,
                      data_origin="synthetic_demo_do_not_use_for_risk_claims"))


# ------------------------------------------------------------------ verification_and_activity_logs (Dataset 10)
def state_at(a, t):
    if a["revoked"] and t >= a["revoked"]: return "revoked"
    if t >= a["expiry"]: return "expired"
    return "active"


def rnd_time(lo, hi): return lo + timedelta(seconds=random.randint(0, max(1, int((hi - lo).total_seconds()))))


def events(a):
    ev = []

    def E(t, et, at, ai, out, det):
        ev.append(dict(t=t, event_type=et, actor_type=at, actor_id=ai, application_id=a["aid"], vendor_id=a["vid"],
                       report_id=a["rid"], consent_id=a["cid"], outcome=out, details=det,
                       removable=et in ("report_accessed", "report_verification_attempt")))
    E(a["granted"], "consent_granted", "vendor", a["vid"], "success", f"scope={';'.join(a['scope'])}; lender={a['lender']}; expires={ts(a['expiry'])}")
    E(a["created"], "report_generated", "system", "assessment-service", "success", f"score={a['score']}; band={a['band']}; hash={a['hash'][:12]}")
    E(a["created"] + timedelta(seconds=random.randint(10, 300)), "report_shared", "system", "consent-service", "success", f"shared with {a['lender']} within consented scope only")
    for _ in range(random.choice([0, 1, 1, 2, 3])):
        t = rnd_time(a["created"] + timedelta(minutes=5), NOW); s = state_at(a, t)
        if s == "revoked": E(t, "access_denied_consent_revoked", "lender", a["lender"], "denied", "consent revoked by vendor; report content withheld")
        elif s == "expired": E(t, "access_denied_consent_expired", "lender", a["lender"], "denied", "consent expired; report content withheld")
        elif "evidence_document_review" not in a["scope"] and random.random() < .12: E(t, "access_denied_scope", "lender", a["lender"], "denied", "raw evidence documents requested but not in consented scope")
        else: E(t, "report_accessed", "lender", a["lender"], "success", "scope=" + ";".join(a["scope"]))
    for _ in range(random.choice([0, 1, 1, 2])):
        t = rnd_time(a["created"] + timedelta(minutes=10), NOW); s = state_at(a, t)
        if random.random() < .15: out, det = "hash_mismatch", "submitted report hash does not match stored hash; possible tampering"
        elif s == "revoked": out, det = "valid_but_consent_withdrawn", "signature and hash valid; vendor has withdrawn consent"
        elif s == "expired": out, det = "valid_but_consent_expired", "signature and hash valid; consent window has ended"
        else: out, det = "valid", f"signature verified with {KEY_ID}; hash matches"
        E(t, "report_verification_attempt", "lender", a["lender"], out, det)
    if a["revoked"]: E(a["revoked"], "consent_revoked", "vendor", a["vid"], "success", "vendor withdrew consent; lender access disabled")
    elif a["expiry"] < NOW: E(a["expiry"], "consent_expired", "system", "consent-service", "success", "consent window ended; access disabled")
    if a["st"] != "pending": E(rnd_time(a["created"] + timedelta(hours=1), NOW), "application_status_changed", "lender", a["lender"], "success", f"pending -> {a['st']}")
    return ev


rest = [a for a in apps if not a["revoked"]]; random.shuffle(rest)
order = [a for a in apps if a["revoked"]][:25] + rest      # every audit trail starts with revocation cases
log_events = []
for a in order:
    if len(log_events) >= 200: break
    log_events += events(a)
while len(log_events) > 200:
    log_events.remove(random.choice([e for e in log_events if e["removable"]]))
log_events.sort(key=lambda e: e["t"])
logs = [dict(log_id=f"LOG{i:04d}", timestamp=ts(e["t"]), event_type=e["event_type"], actor_type=e["actor_type"], actor_id=e["actor_id"],
             vendor_id=e["vendor_id"], application_id=e["application_id"], report_id=e["report_id"], consent_id=e["consent_id"],
             outcome=e["outcome"], details=e["details"]) for i, e in enumerate(log_events, 1)]

# ------------------------------------------------------------------ write everything
write_csv(DATA / "transactions.csv", txns, ["transaction_id", "vendor_id", "date", "amount", "direction", "description", "category", "verification_status"])
write_csv(DATA / "transaction_labels.csv", labels, ["transaction_id", "description", "amount", "direction", "verified_category", "label_source"])
write_csv(DATA / "vendor_monthly_financials.csv", financials, ["vendor_id", "period_month", "business_type", "business_age_months", "business_receipts", "business_expenses", "net_cashflow", "cashflow_variability", "existing_monthly_debt_payments", "data_completeness", "value_source"])
write_csv(DATA / "loan_repayment_history.csv", loans, ["loan_id", "vendor_id", "loan_amount", "monthly_obligation", "repayment_due_date", "actual_payment_date", "days_past_due", "default_status", "data_origin"])
write_csv(SEEDDB / "vendor_profiles.csv", profiles, ["vendor_id", "vendor_name", "business_type", "business_age_months", "operating_location", "registration_status", "available_alternative_evidence", "onboarded_date"])
write_csv(SEEDDB / "lenders.csv", lenders, ["lender_id", "lender_name", "lender_type", "city", "signing_key_id_trusted"])
write_csv(SEEDDB / "loan_applications.csv", applications, ["application_id", "vendor_id", "requested_amount", "loan_purpose", "preferred_repayment_months", "application_status", "lender_id", "submitted_time"])
write_csv(SEEDDB / "consent_records.csv", consents, ["consent_id", "application_id", "vendor_id", "lender_id", "allowed_data_scope", "purpose", "granted_time", "expiry_time", "revoked_time", "consent_status"])
write_csv(SEEDDB / "evidence_documents.csv", docs, ["document_id", "vendor_id", "document_type", "secure_storage_reference", "content_hash", "verification_status", "uploaded_time", "review_timestamp", "lender_access"])
write_csv(SEEDDB / "assessment_reports.csv", reports, ["report_id", "application_id", "vendor_id", "lender_id", "consent_id", "assessment_score", "score_band", "confidence", "factor_explanations", "limitations", "model_version", "report_hash", "signature_reference", "created_time", "report_status"])
write_csv(SEEDDB / "verification_and_activity_logs.csv", logs, ["log_id", "timestamp", "event_type", "actor_type", "actor_id", "vendor_id", "application_id", "report_id", "consent_id", "outcome", "details"])
