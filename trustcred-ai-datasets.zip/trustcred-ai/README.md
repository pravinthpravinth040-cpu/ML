# TrustCred AI

Vendors turn their own payment history into evidence a lender can verify independently, with the vendor controlling what is shared and able to withdraw consent.

## Seed data (synthetic)
Regenerate everything: `pip install numpy cryptography && python ml-training/generate_datasets.py`

- ML data: `ml-training/data/`
- App/seed data and demo signing keys: `backend/database/seed/`
- Column definitions and rules: `docs/dataset-schema.md`

All values are synthetic. Repayment-risk prediction is out of scope for the prototype.
